"ability.cov" <-
structure(list(cov = structure(c(24.641, 5.991, 33.52, 6.023, 
20.755, 29.701, 5.991, 6.7, 18.137, 1.782, 4.936, 7.204, 33.52, 
18.137, 149.831, 19.424, 31.43, 50.753, 6.023, 1.782, 19.424, 
12.711, 4.757, 9.075, 20.755, 4.936, 31.43, 4.757, 52.604, 66.762, 
29.701, 7.204, 50.753, 9.075, 66.762, 135.292), .Dim = c(6, 6
), .Dimnames = list(c("general", "picture", "blocks", "maze", 
"reading", "vocab"), c("general", "picture", "blocks", "maze", 
"reading", "vocab"))), center = c(0, 0, 0, 0, 0, 0), n.obs = 112), .Names = c("cov", 
"center", "n.obs"))
